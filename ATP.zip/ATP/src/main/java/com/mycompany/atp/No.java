package com.mycompany.atp;
public class No {
   private int info;
   No proximo;
   public String dado;
   public int frequencia;

    public No getProximo() {
        return proximo;
    }    

    public void setProximo(No Proximo) {
        this.proximo = Proximo;
    }
    
    public String getDado() {
        return dado;
    }

    public void setDado(String dado) {
        this.dado = dado;
    }

    public int getFrequencia() {
        return frequencia;
    }

    public void setFrequencia(int frequencia) {
        this.frequencia = frequencia;
    }

    public int getInfo() {
        return info;
    }

    public void setInfo(int info) {
        this.info = info;
    }
   
    
   public No(int info){
       this.info = info;
       this.proximo = null;       
   }    
   
   public No(String a, int e){
       this.dado = a;
       this.frequencia = e;
       this.proximo = null;  
   }

   
}
