package com.mycompany.atp;

import java.util.Scanner;

public class Lista {
    
    public static void main(String args[]){


        ListaSE lista = new ListaSE();       
        lista.inserePrimeiro("Arquivo 55.txt", 23);
        lista.inserePrimeiro("Arquivo 12.txt", 14);
        lista.inserePrimeiro("Arquivo 78.txt", 5);
        lista.inserePrimeiro("Arquivo 65.txt", 8); 
        lista.ordenar();       
        Arvore arvore = new Arvore();
        arvore.adicionar("bola",  "arq1.txt");
        arvore.adicionar("casa",  "arq1.txt");
        arvore.adicionar("dado",  "arq1.txt”");
        arvore.adicionar("bola",  "arq1.txt");
        arvore.adicionar("casa",  "arq1.txt");
        arvore.adicionar("dado",  "arq2.txt");
        arvore.adicionar("bola",  "arq2.txt");
        arvore.adicionar("arvore",  "arq2.txt");
        Buscador busca = new Buscador();
        
        
        Scanner l = new Scanner(System.in);
        int opcao;
        do {
        System.out.println("Opção");
        System.out.println(" 1 -- Inserir");
        System.out.println(" 2 -- Pesquisar");
        System.out.println(" 3 -- Mostrar lista");
        System.out.println(" 4 -- Mostrar Arvore");
        System.out.println(" 5 -- Sair "); 
        System.out.println(" ->  ");
        
        opcao = l.nextInt();
        switch(opcao){
            case 1: {
                System.out.println("Digite o termo");
                Scanner s = new Scanner(System.in);
                String palavra = s.nextLine();
                
                System.out.println("\n Informe o arquivo");
                String arq = s.nextLine();
                arvore.adicionar(palavra, arq);
                break;
            }
            case 2:{
                System.out.println("Digite as palavras pesquisada");
                
                Scanner x = new Scanner(System.in);
                String str = "";
                String[] termos;
                str = x.nextLine();
                System.out.println("Pesquisando por: " + str);
                termos = str.split(" ");
                System.out.println("Resultado: ");
                busca.buscaTermo(termos, lista, arvore);            
                break;
            }
            case 3:{
                System.out.println("Lista");
                lista.imprime();
                System.out.println("\n\n"); 
                break;
            }
            case 4:{
                System.out.println("Arvore");
                arvore.in0der();            
                System.out.println("\n\n"); 
                break;
            }        
        }       
        }while(opcao!=5);
    }  
}
