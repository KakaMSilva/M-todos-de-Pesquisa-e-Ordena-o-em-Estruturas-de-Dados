package com.mycompany.atp;
public class Noarvore {
    public long item;
    public String termo;
    public ListaSE listaArquivos;
    public Noarvore dir;
    public Noarvore esq;

    public Noarvore() {
        this.termo = "";
        listaArquivos = new ListaSE();
        this.dir = null;
        this.esq = null;
    }
  



public Noarvore(String termo){
    this.termo = termo;
    listaArquivos = new ListaSE();
    dir = null;
    esq = null;  
    
}



}
