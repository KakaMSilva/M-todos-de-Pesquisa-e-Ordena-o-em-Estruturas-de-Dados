package com.mycompany.atp;

public class Arvore { 
    private Noarvore raiz;
 
    public Arvore(){
        raiz = null;
}    
    
    
    public void adicionar(String termo, String a){     
        
        Noarvore novoNo = buscar(termo);
        if(novoNo == null){
            novoNo = new Noarvore(termo);
            ListaSE lista = novoNo.listaArquivos;
            lista.ordem(a, 1);            
        }else{
           ListaSE lista = novoNo.listaArquivos;
           No n = lista.buscar(a);
           
          if(n != null)
               n.frequencia++;
          else
            lista.ordem(a, 1);
        return;
    }
        if(raiz == null){
            raiz = novoNo;            
        }else{
         Noarvore atual = raiz;
         Noarvore anterior;
         while(true){
             anterior = atual;
             if (termo.compareTo(atual.termo) < 0){
                 atual = atual.esq;
                 if (atual == null){
                    anterior.esq = novoNo;
                    return;
                 }
                 }else{
                     atual = atual.dir;
                     if(atual ==null){
                         anterior.dir = novoNo;
                         return;
                               
              }            
            }       
         }                                                                                
       }    
    }
    
    
    public Noarvore buscar(String termo){
        if (raiz == null)
            return null;
        Noarvore atual = raiz;
        while (!atual.termo.equals(termo)){
            if(termo.compareTo(atual.termo) < 0)
                atual = atual.esq;
            else
                atual = atual.dir;
            if (atual == null )
                return null;
        }  
        return atual;
    }
    
    public void in0der(){
        in0der(raiz);
    }
    
    public void in0der(Noarvore atual){
        if(atual != null){
          in0der(atual.esq);
            System.out.println("Termo: " + atual.termo + " ");
            atual.listaArquivos.imprime();
            in0der(atual.dir);            
        }  
    }        
}

