package com.mycompany.atp;
public class ListaSE {
   private  No primeiro;
   private No ultimo;
   private int tamanho;
  
   public ListaSE(){
      primeiro = null;
      ultimo = null;
      this.tamanho = 0;
   }

    public No getPrimeiro() {
        return primeiro;
    }

    public void setPrimeiro(No primeiro) {
        this.primeiro = primeiro;
    }

    public No getUltimo() {
        return ultimo;
    }

    public void setUltimo(No ultimo) {
        this.ultimo = ultimo;
    }

    public int getTamanho() {
        return tamanho;
    }

    public void setTamanho(int tamanho) {
        this.tamanho = tamanho;
    }       
  
    public boolean vazia(){
       return(primeiro == null);
    }
   
    
   public void inserePrimeiro(String a, int e){
    No novo = new No(a, e);
    if (!vazia()){
        novo.setProximo(primeiro); 
        primeiro = novo;  
       
    }else{
    primeiro = novo;
    ultimo = novo; 
    }  
    tamanho++;
   }
   
    public void inserePrimeiro(int o){
    No novo = new No(o);
    if (!vazia()){
        novo.setProximo(primeiro); 
        primeiro = novo;  
       
    }else{
    primeiro = novo;
    ultimo = novo; 
    }  
    tamanho++;
   }
         
   public No insereDepois(No novo, String a, int e){
       No n = new No(a, e);
       n.setProximo(novo.getProximo());
       novo.setProximo(n);
       return novo;
   }
   
   public No insereDepois(No novo, int o){
       No n = new No(o);
       n.setProximo(novo.getProximo());
       novo.setProximo(n);
       return novo;
   }
   
   
   
   
   public void insereUltimo(String a, int e){
       if(primeiro == null){
           inserePrimeiro(a, e);
       }else{
           ultimo = insereDepois(ultimo, a, e);           
       }       
       tamanho++;
   }  
   
    public void insereUltimo(int o){
       if(primeiro == null){
           inserePrimeiro(o);
       }else{
           ultimo = insereDepois(ultimo, o);           
       }       
       tamanho++;
   } 
   
   public void imprime(){
       No p = primeiro;          
       while(p != null){  
           System.out.println("Arquivo: " + p.getDado() + " Frequencia: " + p.getFrequencia());
           p = p.getProximo();
           }
     
       }
   
   public void ordenar(){
     No[] vetor = new No[this.tamanho];  // cria um vetor para armazenar os nós da lista  
     No p = this.primeiro; 
       for(int i=0; i < vetor.length; i++){  // armazena os nos no vetor
          vetor[i] = p;
          p = p.getProximo();
       }
       quickSort(vetor, 0, vetor.length - 1);
       p = this.primeiro = vetor[0];
       ultimo = vetor[vetor.length - 1];
       for(int i=1; i < vetor.length; i++){ 
          p.setProximo(vetor[i]);
          p = p.getProximo();
       }
       p.setProximo(null);
    }
   
   private static void quickSort(No[] vetor, int inicio, int fim) {
        if (inicio < fim) {
               int posicaoPivo = separar(vetor, inicio, fim);
               quickSort(vetor, inicio, posicaoPivo - 1);
               quickSort(vetor, posicaoPivo + 1, fim);
        }

    }

   private static int separar(No[] vetor, int inicio, int fim) {
        No pivo = vetor[inicio]; // altere o tipo da variável pivo para Node
        int i = inicio + 1, f = fim;
        while (i <= f) {
               if (vetor[i].getFrequencia() >= pivo.getFrequencia())
                      i++;
               else if (pivo.getFrequencia() > vetor[f].getFrequencia())
                      f--;
               else {
                      No troca = vetor[i];  // altere o tipo da variável troca para Node
                      vetor[i] = vetor[f];
                      vetor[f] = troca;
                      i++;
                      f--;
               }
        }
        vetor[inicio] = vetor[f];
        vetor[f] = pivo;
        return f;
    }
   
   public No buscar(int info){ 
    No p = this.primeiro;
    while ((p != null) && (p.getInfo() != info))
        p = p.getProximo();
    return p;  
   }
    
   public No buscar(String a){ 
       No p = this.primeiro;
       while ((p != null) && (!p.getDado().equals(a))) {
            p = p.getProximo();
        }
        return p;
        }  
       
   public void ordem(int e){
   if(vazia())
        inserePrimeiro(e);
    else if (e <= primeiro.getInfo())
        inserePrimeiro(e);
    else if (e <= ultimo.getInfo())
        insereUltimo(e);
    else{
       No p = primeiro;
       No q = null;
       while(p.getInfo() < e){
        q = p;
        p = p.getProximo();
       }
       insereDepois(q, e);
       tamanho++;
    } 
   }
      
    public void ordem(String a, int e){
    if(vazia())
        inserePrimeiro(a, e);
    else if (e >= primeiro.getFrequencia())
        inserePrimeiro(a, e);
    else if (e <= ultimo.getFrequencia())
        insereUltimo(a, e);
    else{
       No p = primeiro;
       No q = null;
       while(p.getFrequencia() > e){
        q = p;
        p = p.getProximo();
       }
       insereDepois(q, a, e);
    }
    }          
}

   
   
   
   
   

    
