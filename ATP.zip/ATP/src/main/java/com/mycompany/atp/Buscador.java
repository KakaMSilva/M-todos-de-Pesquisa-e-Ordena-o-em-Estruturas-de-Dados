package com.mycompany.atp;
public class Buscador {
    public Arvore arquivoArvore;
    public ListaSE listaArq;
    
   
    
public void buscaTermo(String[] termos, ListaSE listaArq, Arvore arquivoarvore){
    
  Noarvore node;

  No p,q;  
    
    for(int i=0; i < termos.length; i++){
      node = arquivoarvore.buscar(termos[i]); 
          if (node != null) { 
              p = node.listaArquivos.getPrimeiro();
          }
          else 
              p = null;
         while(p!=null){
              q = listaArq.buscar(p.dado);
                   if(q != null){
                     q.frequencia += p.frequencia; 
                     
                   }
                   else{
                    listaArq.ordem(p.dado, p.frequencia);
                   }
                       p = p.getProximo();
         }
    }
    listaArq.ordenar();
    listaArq.imprime();
    
}   
}
